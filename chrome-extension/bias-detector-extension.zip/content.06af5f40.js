var e,t;"function"==typeof(e=globalThis.define)&&(t=e,e=null),function(t,n,r,o,a){var i="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},s="function"==typeof i[o]&&i[o],l=s.cache||{},d="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function c(e,n){if(!l[e]){if(!t[e]){var r="function"==typeof i[o]&&i[o];if(!n&&r)return r(e,!0);if(s)return s(e,!0);if(d&&"string"==typeof e)return d(e);var a=Error("Cannot find module '"+e+"'");throw a.code="MODULE_NOT_FOUND",a}u.resolve=function(n){var r=t[e][1][n];return null!=r?r:n},u.cache={};var p=l[e]=new c.Module(e);t[e][0].call(p.exports,u,p,p.exports,this)}return l[e].exports;function u(e){var t=u.resolve(e);return!1===t?{}:c(t)}}c.isParcelRequire=!0,c.Module=function(e){this.id=e,this.bundle=c,this.exports={}},c.modules=t,c.cache=l,c.parent=s,c.register=function(e,n){t[e]=[function(e,t){t.exports=n},{}]},Object.defineProperty(c,"root",{get:function(){return i[o]}}),i[o]=c;for(var p=0;p<n.length;p++)c(n[p]);if(r){var u=c(r);"object"==typeof exports&&"undefined"!=typeof module?module.exports=u:"function"==typeof e&&e.amd?e(function(){return u}):a&&(this[a]=u)}}({"4gaGD":[function(e,t,n){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(n),r.export(n,"config",()=>d);var o=e("./api"),a=e("./components/button"),i=e("./components/highlight"),s=e("./components/styles"),l=e("./components/textarea-overlay");let d={matches:["<all_urls>"],all_frames:!0};(0,s.injectStyles)();let c=null;function p(){let e=function(){let e=document.activeElement;for(;e&&"IFRAME"===e.tagName;)try{let t=e.contentDocument;if(!t)break;e=t.activeElement}catch{return null}return e}();if(!e)return;let t=e.closest('[contenteditable="true"],textarea,input[type="text"],input[type="email"],input[type="search"],[role="textbox"]');t&&t!==c?(c=t,(0,a.showButton)(t,u)):!t&&c&&((0,a.hideButton)(),c=null)}async function u(){if(!c)return;let e=c,t=function(e){let t;if("value"in e&&void 0!==e.value)return e.value;let n=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,null),r="";for(;t=n.nextNode();)r+=t.textContent;return r.replace(/\u200B/g,"").trim()}(e);if(!t.trim()){alert("No text to analyze");return}(0,a.setButtonLoading)(!0);try{let n=await (0,o.analyzeBias)(t);console.log("Issues received:",n),console.log("Element type:",e.tagName,"isContentEditable:",e.isContentEditable),0===n.length?(0,a.setButtonSuccess)():location.hostname.includes("outlook")?function(e){let t=e.map((e,t)=>`${t+1}. "${e.phrase}" (${e.severity})
   \u2192 ${e.explanation}
   Suggestion: ${e.replacement}`).join("\n\n");alert(`Found ${e.length} bias issue(s):

${t}`)}(n):"textarea"===e.tagName.toLowerCase()?(0,l.highlightTextarea)(e,n):(0,i.highlightIssues)(e,n)}catch(e){console.error("Analysis failed:",e),alert("Analysis failed. Check console for details.")}(0,a.setButtonLoading)(!1)}!function(){setInterval(p,500),document.addEventListener("scroll",()=>(0,a.updateButtonPosition)(c),!0),window.addEventListener("resize",()=>(0,a.updateButtonPosition)(c));let e=new MutationObserver(()=>{p()});e.observe(document.body,{childList:!0,subtree:!0}),console.log("Bias Detector loaded",window.location.href)}()},{"./api":"dHeft","./components/button":"fXkPK","./components/highlight":"7fyvA","./components/styles":"a1SFx","./components/textarea-overlay":"bJ3RC","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],dHeft:[function(e,t,n){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");async function o(e){let t=await fetch("https://bias-detector-2ih2.onrender.com/analyze",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:e})});if(!t.ok)throw Error(`API error: ${t.status}`);let n=await t.json();return console.log("API response:",n),n.results?.biases||[]}r.defineInteropFlag(n),r.export(n,"analyzeBias",()=>o)},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],cHUbl:[function(e,t,n){n.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},n.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},n.exportAll=function(e,t){return Object.keys(e).forEach(function(n){"default"===n||"__esModule"===n||t.hasOwnProperty(n)||Object.defineProperty(t,n,{enumerable:!0,get:function(){return e[n]}})}),t},n.export=function(e,t,n){Object.defineProperty(e,t,{enumerable:!0,get:n})}},{}],fXkPK:[function(e,t,n){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(n),r.export(n,"showButton",()=>i),r.export(n,"hideButton",()=>s),r.export(n,"updateButtonPosition",()=>l),r.export(n,"setButtonLoading",()=>d),r.export(n,"setButtonSuccess",()=>c);let o=null,a=null;function i(e,t){let n=function(e){if(location.hostname.includes("linkedin")){let t=e.closest('[role="dialog"], [aria-modal="true"], .artdeco-modal');if(t)return t}return document.body}(e);o&&a!==n&&(o.remove(),o=null),o||((o=document.createElement("button")).className="check-btn",o.innerHTML="B",o.addEventListener("mousedown",e=>e.preventDefault()),o.addEventListener("click",t),n.appendChild(o),a=n),l(e),o.style.display="flex"}function s(){o&&(o.style.display="none")}function l(e){if(!o||!e)return;let t=e.getBoundingClientRect();o.style.position="fixed",o.style.bottom=`${window.innerHeight-t.bottom+8}px`,o.style.right=`${window.innerWidth-t.right+8}px`,o.style.top="auto",o.style.left="auto",o.style.zIndex="1000000000"}function d(e){o&&(o.innerHTML=e?"...":"B")}function c(){o&&(o.innerHTML="\u2713",setTimeout(()=>{o&&(o.innerHTML="B")},1500))}},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],"7fyvA":[function(e,t,n){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(n),r.export(n,"highlightIssues",()=>a),r.export(n,"clearHighlights",()=>s);var o=e("./card");function a(e,t){console.log("[BiasDetector] highlightIssues called"),console.log("[BiasDetector] Element innerHTML BEFORE:",e.innerHTML.substring(0,500)),s(e);let n=[];t.forEach((e,t)=>{e.positions.forEach(r=>{n.push({start:r.start,end:r.end,issue:e,issueIndex:t})})}),n.sort((e,t)=>e.start-t.start||t.end-e.end);let r=[];for(let e of n){let t=r.some(t=>e.start<t.end&&e.end>t.start);t||r.push(e)}let a=[...r].sort((e,t)=>t.start-e.start);for(let t of(console.log("[BiasDetector] Ranges to highlight:",a.map(e=>({start:e.start,end:e.end,phrase:e.issue.phrase}))),a))(function(e,t,n,r,o){let a=0,s=!1;!function e(l){if(l.nodeType===Node.TEXT_NODE){let e=l.textContent?.length||0,i=a,d=a+e;if(d>t&&i<n){let a=Math.max(0,t-i),s=Math.min(e,n-i);if(a<s){let e=l.textContent||"",t=document.createElement("span");t.className=`bias-highlight severity-${r.severity}`,t.dataset.biasIndex=String(o),t.textContent=e.slice(a,s);let n={low:{bg:"rgba(34, 197, 94, 0.25)",border:"#22c55e"},medium:{bg:"rgba(234, 179, 8, 0.25)",border:"#eab308"},high:{bg:"rgba(239, 68, 68, 0.25)",border:"#ef4444"}},i=n[r.severity]||n.medium;t.style.cssText=`background: ${i.bg} !important; border-bottom: 2px solid ${i.border} !important; border-radius: 2px !important; padding: 1px 0 !important; cursor: pointer !important;`;let d=e.slice(0,a),c=e.slice(s),p=l.parentNode;return p&&(c&&p.insertBefore(document.createTextNode(c),l.nextSibling),p.insertBefore(t,l.nextSibling),d?l.textContent=d:p.removeChild(l)),!0}}a=d,s=!1}else if(l.nodeType===Node.ELEMENT_NODE){let t=l.tagName;if(i.has(t)&&a>0&&!s&&(a+=1,s=!0),"BR"===t)return a+=1,s=!0,!1;for(let t of Array.from(l.childNodes))if(e(t))return!0;i.has(t)&&"BR"!==t&&!s&&(a+=1,s=!0)}return!1}(e)})(e,t.start,t.end,t.issue,t.issueIndex);console.log("[BiasDetector] Element innerHTML AFTER:",e.innerHTML.substring(0,500)),e.querySelectorAll(".bias-highlight").forEach(n=>{n.addEventListener("mouseenter",n=>{let r=n.target,a=parseInt(r.dataset.biasIndex||"0"),i=t[a];i&&(0,o.showCard)(r,i,()=>{var t;return t=i.replacement,void(r.replaceWith(document.createTextNode(t)),e.normalize())},()=>(function(e){e.replaceWith(document.createTextNode(e.textContent||""))})(r))}),n.addEventListener("mouseleave",o.scheduleHideCard)})}let i=new Set(["DIV","P","BR","LI","TR","H1","H2","H3","H4","H5","H6"]);function s(e){let t=e.querySelectorAll(".bias-highlight");t.forEach(e=>{e.replaceWith(document.createTextNode(e.textContent||""))}),e.normalize()}},{"./card":"eegYK","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],eegYK:[function(e,t,n){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(n),r.export(n,"showCard",()=>i),r.export(n,"scheduleHideCard",()=>s),r.export(n,"hideCard",()=>l);let o=null,a=null;function i(e,t,n,r){l();let i=e.getBoundingClientRect(),s=document.createElement("div");s.className="hover-card",s.innerHTML=`
    <div class="card-header">
      <div>
        <span class="card-badge severity-${t.severity}">${t.severity}</span>
        <span class="card-category">${t.category}</span>
      </div>
    </div>
    <p class="card-explanation">${t.explanation}</p>
    <div class="card-suggestion">
      <div class="card-suggestion-label">Suggested replacement:</div>
      <div class="card-suggestion-text">"${t.replacement}"</div>
    </div>
    <div class="card-actions">
      <button class="card-btn primary" data-action="replace">Replace</button>
      <button class="card-btn secondary" data-action="ignore">Ignore</button>
    </div>
  `;let d=i.bottom+12,c=i.left;c+320>window.innerWidth&&(c=window.innerWidth-330),c<10&&(c=10),d+250>window.innerHeight&&(d=i.top-260),s.style.cssText=`
    position: fixed !important;
    top: ${d}px !important;
    left: ${c}px !important;
    z-index: 2147483647 !important;
    background: white !important;
    border-radius: 8px !important;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15) !important;
    padding: 12px !important;
    max-width: 320px !important;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
    font-size: 13px !important;
    line-height: 1.5 !important;
    color: #374151 !important;
  `,s.querySelector('[data-action="replace"]')?.addEventListener("click",()=>{n(),l()}),s.querySelector('[data-action="ignore"]')?.addEventListener("click",()=>{r(),l()}),s.addEventListener("mouseenter",()=>{a&&clearTimeout(a)}),s.addEventListener("mouseleave",l),document.body.appendChild(s),o=s}function s(){a=setTimeout(l,150)}function l(){o&&(o.remove(),o=null)}},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],a1SFx:[function(e,t,n){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(n),r.export(n,"injectStyles",()=>i);let o=`
span.bias-highlight {
  border-radius: 2px !important;
  padding: 1px 0 !important;
  cursor: pointer !important;
  display: inline !important;
}

span.bias-highlight.severity-low {
  background: rgba(34, 197, 94, 0.25) !important;
  border-bottom: 2px solid #22c55e !important;
}

span.bias-highlight.severity-medium {
  background: rgba(234, 179, 8, 0.25) !important;
  border-bottom: 2px solid #eab308 !important;
}

span.bias-highlight.severity-high {
  background: rgba(239, 68, 68, 0.25) !important;
  border-bottom: 2px solid #ef4444 !important;
}

.hover-card {
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  padding: 12px;
  max-width: 320px;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  font-size: 13px;
  line-height: 1.5;
  color: #374151;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.card-badge {
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
}

.card-badge.severity-low {
  background: rgba(34, 197, 94, 0.2);
  color: #15803d;
}

.card-badge.severity-medium {
  background: rgba(234, 179, 8, 0.2);
  color: #a16207;
}

.card-badge.severity-high {
  background: rgba(239, 68, 68, 0.2);
  color: #dc2626;
}

.card-category {
  color: #6b7280;
  font-size: 12px;
  margin-left: 8px;
}

.card-explanation {
  margin: 0 0 10px 0;
  color: #374151;
}

.card-suggestion {
  background: #f3f4f6;
  padding: 10px;
  border-radius: 6px;
  margin-bottom: 12px;
}

.card-suggestion-label {
  font-size: 11px;
  color: #6b7280;
  margin-bottom: 4px;
}

.card-suggestion-text {
  font-weight: 500;
  color: #111827;
}

.card-actions {
  display: flex;
  gap: 8px;
}

.card-btn {
  flex: 1;
  padding: 8px 12px;
  border: none;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
}

.card-btn.primary {
  background: #3b82f6;
  color: white;
}

.card-btn.primary:hover {
  background: #2563eb;
}

.card-btn.secondary {
  background: #e5e7eb;
  color: #374151;
}

.card-btn.secondary:hover {
  background: #d1d5db;
}

.check-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  padding: 0;
  background: #3b82f6;
  color: white;
  border: none;
  border-radius: 50%;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  transition: transform 0.15s ease, background 0.15s ease;
}

.check-btn:hover {
  background: #2563eb;
  transform: scale(1.1);
}

.textarea-overlay {
  pointer-events: none;
  z-index: 999999;
}

.textarea-backdrop {
  white-space: pre-wrap;
  word-wrap: break-word;
  overflow-wrap: break-word;
}

.textarea-backdrop mark.bias-highlight {
  color: transparent;
  border-radius: 2px;
}
`,a=!1;function i(){if(a)return;let e=document.createElement("style");e.textContent=o,document.head.appendChild(e),a=!0}},{"@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}],bJ3RC:[function(e,t,n){var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(n),r.export(n,"highlightTextarea",()=>c),r.export(n,"clearTextareaOverlay",()=>h);var o=e("./card");let a=null,i=null,s=null,l=[],d=[];function c(e,t){h(),s=e,l=t;let n=[];for(let e of(t.forEach((e,t)=>{e.positions.forEach(r=>{n.push({start:r.start,end:r.end,issue:e,issueIndex:t})})}),n.sort((e,t)=>e.start-t.start||t.end-e.end),d=[],n)){let t=d.some(t=>e.start<t.end&&e.end>t.start);t||d.push(e)}(i=document.createElement("div")).className="textarea-backdrop",(a=document.createElement("div")).className="textarea-overlay";let r=window.getComputedStyle(e);["fontFamily","fontSize","fontWeight","lineHeight","letterSpacing","wordSpacing","textAlign","textIndent","whiteSpace","wordWrap","wordBreak","padding","paddingTop","paddingRight","paddingBottom","paddingLeft","border","borderRadius","boxSizing"].forEach(e=>{i.style[e]=r[e]});let c=e.getBoundingClientRect();a.style.position="fixed",a.style.top=`${c.top}px`,a.style.left=`${c.left}px`,a.style.width=`${c.width}px`,a.style.height=`${c.height}px`,a.style.pointerEvents="none",a.style.zIndex="999999",a.style.overflow="hidden",i.style.width="100%",i.style.height="100%",i.style.overflow="auto",i.style.pointerEvents="none",i.style.color="transparent",i.style.background="transparent",a.appendChild(i),document.body.appendChild(a),e.dataset.originalBg=e.style.background,e.style.background="transparent",function e(){if(!i||!s)return;let t=s.value,n="",r=0;for(let e of d){n+=g(t.slice(r,e.start));let o=t.slice(e.start,e.end);n+=`<mark class="bias-highlight severity-${e.issue.severity}" data-bias-index="${e.issueIndex}">${g(o)}</mark>`,r=e.end}n+=g(t.slice(r))+"<br>",i.innerHTML=n,p(),function(){if(!a||!s)return;let t=a.querySelector(".interaction-layer");t&&t.remove();let n=document.createElement("div");n.className="interaction-layer",n.style.position="absolute",n.style.top="0",n.style.left="0",n.style.width="100%",n.style.height="100%",n.style.pointerEvents="none",i?.querySelectorAll(".bias-highlight").forEach(t=>{let r=t.getBoundingClientRect(),i=a.getBoundingClientRect(),c=document.createElement("div");c.style.position="absolute",c.style.top=`${r.top-i.top}px`,c.style.left=`${r.left-i.left}px`,c.style.width=`${r.width}px`,c.style.height=`${r.height}px`,c.style.pointerEvents="auto",c.style.cursor="pointer";let p=parseInt(t.dataset.biasIndex||"0"),u=l[p];c.addEventListener("mouseenter",()=>{u&&o.showCard(t,u,()=>(function(t){if(!s)return;let n=l[t];if(!n)return;let r=d.find(e=>e.issueIndex===t);if(!r)return;let o=s.value;s.value=o.slice(0,r.start)+n.replacement+o.slice(r.end);let a=n.replacement.length-(r.end-r.start);(d=d.filter(e=>e!==r)).forEach(e=>{e.start>r.start&&(e.start+=a,e.end+=a)}),d.length>0?e():h(),s.dispatchEvent(new Event("input",{bubbles:!0}))})(p),()=>{(d=d.filter(e=>e.issueIndex!==p)).length>0?e():h()})}),c.addEventListener("mouseleave",o.scheduleHideCard),n.appendChild(c)}),a.appendChild(n)}()}(),e.addEventListener("scroll",p),e.addEventListener("input",f),window.addEventListener("resize",u),window.addEventListener("scroll",u,!0)}function p(){i&&s&&(i.scrollTop=s.scrollTop,i.scrollLeft=s.scrollLeft)}function u(){if(!a||!s)return;let e=s.getBoundingClientRect();a.style.top=`${e.top}px`,a.style.left=`${e.left}px`,a.style.width=`${e.width}px`,a.style.height=`${e.height}px`}function f(){h()}function g(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\n/g,"<br>")}function h(){a&&(a.remove(),a=null),i&&(i=null),s&&(s.style.background=s.dataset.originalBg||"",s.removeEventListener("scroll",p),s.removeEventListener("input",f),s=null),window.removeEventListener("resize",u),window.removeEventListener("scroll",u,!0),l=[],d=[],(0,o.hideCard)()}},{"./card":"eegYK","@parcel/transformer-js/src/esmodule-helpers.js":"cHUbl"}]},["4gaGD"],"4gaGD","parcelRequirece9f"),globalThis.define=t;